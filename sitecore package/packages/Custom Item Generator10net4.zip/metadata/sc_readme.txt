The first configuration change that will need to be made is to add the following command to your ~/App_Config/Commands.config file.

<command name="devtools:generatecustomitem" type="CustomItemGenerator.SitecoreApp.CustomItemGeneratorCommand,CustomItemGenerator" />

Then you will need to adjust the custom item configuration file found here

~/App_Config/Include/CustomItem.config

There are two settings you have the be concerned with to start

Base.Namespace - This will be the base of the auto generated namespace for a custom item class.  The rest of the namespace (by default) will be generated from the template folder structure.

Base.FileOutputPath - This will be the base folder that the custom item class files will be written to.  The rest of the file path (by default) will be generated from the template folder structure.

To start that should be it.  There are other configuration settings that can be modified, but you will not need to adjust those for the default setup.